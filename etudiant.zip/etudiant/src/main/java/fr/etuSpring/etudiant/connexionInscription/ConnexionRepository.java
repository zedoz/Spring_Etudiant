package fr.etuSpring.etudiant.connexionInscription;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ConnexionRepository extends JpaRepository<ConnexionModel, Long> {
 
}

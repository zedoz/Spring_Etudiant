package fr.etuSpring.etudiant.connexionInscription;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import fr.etuSpring.etudiant.connexionInscription.ConnexionRepository;
 
@Controller
public class ConnexionController {
 
    @Autowired
    private ConnexionRepository userRepo;
     
    
}

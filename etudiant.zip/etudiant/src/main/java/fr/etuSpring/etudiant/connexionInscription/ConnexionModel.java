package fr.etuSpring.etudiant.connexionInscription;
import jakarta.persistence.*;

@Entity
@Table(name="etudiants")
public class ConnexionModel {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "numEtudiant", nullable = false)
	int numEtudiant;

	@Column(name="nomEtudiant")
	String nomEtudiant;

	@Column(name="prenomEtudiant")
	String prenomEtudiant;
	
	@Column(name="mailEtudiant")
	String mailEtudiant;
	
	@Column(name="annee")
	int annee;
	
	@Column(name="codeDiplome")
	int codeDiplome;
	
	@Column(name="mdp")
	String mdp;

	public int getNumEtudiant() {
		return numEtudiant;
	}

	public void setNumEtudiant(int numEtudiant) {
		this.numEtudiant = numEtudiant;
	}

	public String getNomEtudiant() {
		return nomEtudiant;
	}

	public void setNomEtudiant(String nomEtudiant) {
		this.nomEtudiant = nomEtudiant;
	}

	public String getPrenomEtudiant() {
		return prenomEtudiant;
	}

	public void setPrenomEtudiant(String prenomEtudiant) {
		this.prenomEtudiant = prenomEtudiant;
	}

	public String getMailEtudiant() {
		return mailEtudiant;
	}

	public void setMailEtudiant(String mailEtudiant) {
		this.mailEtudiant = mailEtudiant;
	}

	public int getAnnee() {
		return annee;
	}

	public void setAnnee(int annee) {
		this.annee = annee;
	}

	public int getCodeDiplome() {
		return codeDiplome;
	}

	public void setCodeDiplome(int codeDiplome) {
		this.codeDiplome = codeDiplome;
	}

	public String getMdp() {
		return mdp;
	}

	public void setMdp(String mdp) {
		this.mdp = mdp;
	}
	
	
}

